<?php
/*
BLENDING ALGORITHM

F,


*/
define(INPUT_CSV,		'master.csv') ;
define(OUTPUT_DIR,		'w:/sox-output/') ; // include trailing slash!

// Length of sound generated (seconds)
define(SND_LENGTH,3) ;

// Frequency offets for binaural beats
define(BOFFST_LT,-6) ;
define(BOFFST_RT,6) ;

// Templates for SoX commands
define(SOX_GENERATE,	'c:/sox/sox.exe -n {OUTPUT_FILE} synth {DURATION} sine {FREQ}') ;
define(SOX_MULTIPLY,	'c:/sox/sox.exe -T {INPUT_FILE1} {INPUT_FILE2} {OUTPUT_FILE}') ;
define(SOX_STEREOMX,	'c:/sox/sox.exe -M {LEFT_FILE} {RIGHT_FILE} {OUTPUT_FILE} remix -m 1v1,2v0 1v0,2v1') ;
define(SOX_STEREOBLEND,	'c:/sox/sox.exe -m {INPUT_FILE1} {INPUT_FILE2} {OUTPUT_FILE} remix -m 1v0.5,2v0.5 1v0.5,2v0.5') ;

// Example, mixing > 2 tracks ... from http://forum.videohelp.com/threads/348768-sox-audio-mixing-4-channels-down-to-2
// sox -M "Track 1.wav" "Track 2.wav" -v 0.9 "Track 3.wav" -v 0.9 "Track 4.wav" Output.wav -remix -m 1v0.6,2v0.4,3v1.0 1v0.4,2v0.6,4v1.0
define(VALID_PREFIXES,	'BF,LO,H3,H6,H9') ;

$CMD 		= '' ;

$ARR_LINE 	= array() ;

$ARR_PREFIXES = split(',',VALID_PREFIXES) ;

// Which frequency we're currently processing
$IDX_FREQ	= 0 ;

// Current 'prefix' of frequency being processed (BF = Base Freq, LO = looct, H1, H2, H3)
$PFX_FREQ   = '' ;

// Open CSV file, parse lines into $ARR_LINEs
// (each line is also an array)
$FH = fopen(INPUT_CSV,'r') ;

$FREQ_LT = 0 ;
$FREQ_RT = 0 ;

// Holds filename as frequencies are being generated
$FILENAME_LEFT 		= '' ;
$FILENAME_RIGHT 	= '' ;
$FILENAME_STEREO 	= '' ;
$FILENAME_CARRIER 	= '' ; // carrier file, mono
$FILENAME_CARRIER_S = '' ; // carrier file, stereo (identical tracks, mixed from carrier file above)
$FILENAME_STEROMUX  = '' ; // stereo multiplied with carrier

/*
while(!feof($FH)){
	$ARR_LINE = fgetcsv($FH,1024) ;
	
	$PFX_FREQ = substr($ARR_LINE[0],0,2) ;

	if(!in_array($PFX_FREQ,$ARR_PREFIXES)) continue ;

	if(substr($ARR_LINE[0],0,2) == 'BF')
	{
		$IDX_FREQ = substr($ARR_LINE[0],2,1) ;
		echo("Set IDX_FREQ to $IDX_FREQ \n\n") ;
	}
	
	echo('Processing frequency '.$PFX_FREQ.'-'.$IDX_FREQ.' ... ') ;
	
	// Generate a series of frequency files named with current $IDX_FREQ
	//freq_gen($ARR_LINE) ;

	//print_freq($ARR_LINE) ;

	gen_freq_series($ARR_LINE) ;
	echo("\n") ;
}
*/

fclose($FH) ;

echo("\n\n =================== BLENDING INTO FINAL ===============\n\n") ;

$fn_add = '' ;
$fn_adds = array() ;

for($bf = 1; $bf < 8; $bf++)
{
	//$fn_add = 'SM-' . $bf . '-BF.wav' ;
	//$fn_adds[] = $fn_add ;

	foreach($ARR_PREFIXES as $pfx)
	{
		$fn_add = 'SM-' . $bf . '-' . $pfx . '.wav' ;
		$fn_adds[] = $fn_add ;

		for($oct = 1; $oct < 4; $oct++)
		{
			// Next frequency to blend in
			$fn_add = 'SM-' . $bf . '-' . $pfx . '-O' . $oct . '.wav' ;

			$fn_adds[] = $fn_add ;
		}
	}

	// Form a honkin' fuckin huge SOX command and blend all these files ...
	$cmd = 'c:/sox/sox.exe -m ' ;

	foreach($fn_adds as $fn_add)
	{
		echo($fn_add."\n") ;
		$cmd .= OUTPUT_DIR.$fn_add.' ' ;
	}

	$cmd .= OUTPUT_DIR.'SMF-' . $bf . '.wav' ;
	echo("\n") ;
	echo('SOX CMD: '.$cmd) ;
	echo("\n-------------\n") ;
	exec($cmd) ;

	$fn_adds = array() ;
}




// Successively blend overtones ... S-BF-1-BF.wav, S-BF-1-BF-01.wav
// 'SER' prefix denotes blended harmonic series ...
//sox_stereoblend('SM-1-BF.wav','SM-1-BF-O1.wav','SMF-1.wav') ;
//sox_stereoblend('SMF-1.wav','SM-1-BF-O2.wav','SMF-1.wav') ;
//sox_stereoblend('SMF-1.wav','SM-1-BF-O3.wav','SMF-1.wav') ;

function print_freq($ARR_LINE)
{
	echo('F: '.$ARR_LINE[2]) ;
	echo('  O1: '.$ARR_LINE[4]) ;
	echo('  O2: '.$ARR_LINE[5]) ;
	echo('  O3: '.$ARR_LINE[6]) ;
	echo('  CF: '.$ARR_LINE[13]) ;
	echo('  C1: '.$ARR_LINE[14]) ;
	echo('  C2: '.$ARR_LINE[15]) ;
	echo('  C3: '.$ARR_LINE[16]) ;

	// 13,14,15,16 are carrier frequencies for F, O1, O2, O3 respectively
}

function gen_freq_series($ARR_LINE)
{
	global $IDX_FREQ ;
	global $PFX_FREQ ;
	global $FILENAME_RIGHT ;
	global $FILENAME_LEFT ;
	global $FILENAME_CARRIER ;
	global $FILENAME_CARRIER_S ;
	global $FILENAME_STEREO ;
	global $FILENAME_STEROMUX ; // stereo multiplied with carrier

	//echo('Generating frequency series '+$IDX_FREQ) ;
	// Process fundamental ...
	$FREQ_LT = $ARR_LINE[2] + BOFFST_LT ;
	$FREQ_RT = $ARR_LINE[2] + BOFFST_RT ;

	// Generate left channel
	$FILENAME_LEFT = $IDX_FREQ.'-'.$PFX_FREQ.'-L.wav' ;
	sox_generate($FILENAME_LEFT,SND_LENGTH,$FREQ_LT) ;

	// Generate right channel
	$FILENAME_RIGHT = $IDX_FREQ.'-'.$PFX_FREQ.'-R.wav' ;
	sox_generate($FILENAME_RIGHT,SND_LENGTH,$FREQ_RT) ;

	// Mix them into a single stereo file
	$FILENAME_STEREO = 'S-'.$IDX_FREQ.'-'.$PFX_FREQ.'.wav' ;
	sox_stereomx($FILENAME_LEFT,$FILENAME_RIGHT,$FILENAME_STEREO) ;

	// Generate carrier frequency for fundamental (in column 13)
	$FILENAME_CARRIER = 'C-'.$IDX_FREQ.'-'.$PFX_FREQ.'.wav' ;
	sox_generate($FILENAME_CARRIER,SND_LENGTH,$ARR_LINE[13]) ;
	
	// Mix into a stereo carrier file
	$FILENAME_CARRIER_S = 'CS-'.$IDX_FREQ.'-'.$PFX_FREQ.'.wav' ;
	sox_stereomx($FILENAME_CARRIER,$FILENAME_CARRIER,$FILENAME_CARRIER_S) ;

	// Multiply with stereo file to create volume envelope
	$FILENAME_STEREOMUX = 'SM-'.$IDX_FREQ.'-'.$PFX_FREQ.'.wav' ;
	sox_multiply($FILENAME_STEREO,$FILENAME_CARRIER_S,$FILENAME_STEREOMUX) ;


	// Process overtones (in columns 4,5,6)
	// $i tracks overtone number ...
	$i = 1 ;
	foreach(array(4,5,6) as $col)
	{
		$FREQ_LT = $ARR_LINE[$col] + BOFFST_LT ;
		$FREQ_RT = $ARR_LINE[$col] + BOFFST_RT ;

		// Generate left channel
		$FILENAME_LEFT = $IDX_FREQ.'-'.$PFX_FREQ.'-O'.$i.'-L.wav' ;
		sox_generate($FILENAME_LEFT,SND_LENGTH,$FREQ_LT) ;

		// Generate right channel
		$FILENAME_RIGHT = $IDX_FREQ.'-'.$PFX_FREQ.'-O'.$i.'-R.wav' ;
		sox_generate($FILENAME_RIGHT,SND_LENGTH,$FREQ_RT) ;

		// Mix them into a single stereo file
		$FILENAME_STEREO = 'S-'.$IDX_FREQ.'-'.$PFX_FREQ.'-O'.$i.'.wav' ;
		sox_stereomx($FILENAME_LEFT,$FILENAME_RIGHT,$FILENAME_STEREO) ;
		
		// Generate carrier frequency for fundamental (carrier value in column 13)
		$FILENAME_CARRIER = 'C-'.$IDX_FREQ.'-'.$PFX_FREQ.'-O'.$i.'.wav' ;
		sox_generate($FILENAME_CARRIER,SND_LENGTH,$ARR_LINE[13]) ;

		// Mix into a stereo carrier file
		$FILENAME_CARRIER_S = 'CS-'.$IDX_FREQ.'-'.$PFX_FREQ.'-O'.$i.'.wav' ;
		sox_stereomx($FILENAME_CARRIER,$FILENAME_CARRIER,$FILENAME_CARRIER_S) ;

		$i++ ;
	}

	// Process carrier frequencies for overtones (in columns 14,15,16)
	// $i tracks overtone number ...
	$i = 1 ;
	foreach(array(14,15,16) as $col)
	{		
		// Re-construct stereo filename
		$FILENAME_STEREO = 'S-'.$IDX_FREQ.'-'.$PFX_FREQ.'-O'.$i.'.wav' ;

		// Generate carrier frequency
		$FILENAME_CARRIER_S = 'CS-'.$IDX_FREQ.'-'.$PFX_FREQ.'-O'.$i.'.wav' ;
		sox_generate($FILENAME_CARRIER,SND_LENGTH,$ARR_LINE[$col]) ;

		// Multiply with stereo file to create volume envelope
		$FILENAME_STEREOMUX = 'SM-'.$IDX_FREQ.'-'.$PFX_FREQ.'-O'.$i.'.wav' ;
		sox_multiply($FILENAME_STEREO,$FILENAME_CARRIER_S,$FILENAME_STEREOMUX) ;

		$i++ ;
	}

	// Eventually we'll blend harmonies to this base frequency too ...
}

function sox_generate($output_file,$duration,$freq)
{
	$CMD = SOX_GENERATE ;

	$CMD = str_replace('{OUTPUT_FILE}', OUTPUT_DIR.$output_file,$CMD) ;
	$CMD = str_replace('{DURATION}',	$duration,$CMD) ;
	$CMD = str_replace('{FREQ}',		$freq,$CMD) ;

	echo("Running SOX command: $CMD \n") ;
	exec($CMD) ;
}

function sox_multiply($input_file1,$input_file2,$output_file)
{
	$CMD = SOX_MULTIPLY ;

	$CMD = str_replace('{INPUT_FILE1}',OUTPUT_DIR.$input_file1,$CMD) ;
	$CMD = str_replace('{INPUT_FILE2}',OUTPUT_DIR.$input_file2,$CMD) ;
	$CMD = str_replace('{OUTPUT_FILE}',OUTPUT_DIR.$output_file,$CMD) ;

	echo("Running SOX command: $CMD \n") ;
	exec($CMD) ;
}

// Combines L & R waveforms into a single stereo file
function sox_stereomx($left_file,$right_file,$output_file)
{
	$CMD = SOX_STEREOMX ;

	$CMD = str_replace('{LEFT_FILE}',OUTPUT_DIR.$left_file,$CMD) ;
	$CMD = str_replace('{RIGHT_FILE}',OUTPUT_DIR.$right_file,$CMD) ;
	$CMD = str_replace('{OUTPUT_FILE}',OUTPUT_DIR.$output_file,$CMD) ;

	echo("Running SOX command: $CMD \n") ;
	exec($CMD) ;
}

// Combines two stereo files generated by sox_stereomx() into a single stereo file,
// Blending each channel at 50%. Call in a cascaded fashion to layer > 2 tracks
// Eg track1.wav, track2.wav, track3.wav, track4.wav -> stereo-mixdown.wav
// stereoblend(track1.wav,track2.wav)
function sox_stereoblend($file1,$file2,$output_file)
{
	$CMD = SOX_STEREOBLEND ;

	$CMD = str_replace('{INPUT_FILE1}',OUTPUT_DIR.$file1,$CMD) ;
	$CMD = str_replace('{INPUT_FILE2}',OUTPUT_DIR.$file2,$CMD) ;
	$CMD = str_replace('{OUTPUT_FILE}',OUTPUT_DIR.$output_file,$CMD) ;

	echo("Running SOX command: $CMD \n") ;
	exec($CMD) ;
}

//print_r($csv);
?>